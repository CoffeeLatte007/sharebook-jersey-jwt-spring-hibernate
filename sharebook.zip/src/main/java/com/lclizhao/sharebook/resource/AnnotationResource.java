package com.lclizhao.sharebook.resource;

//~--- non-JDK imports --------------------------------------------------------

import com.lclizhao.sharebook.daomain.Annotation;
import com.lclizhao.sharebook.daomain.User_Book;
import com.lclizhao.sharebook.resource.Exception.AppException;
import com.lclizhao.sharebook.service.AnnotationService;
import com.lclizhao.sharebook.service.CollectionService;
import com.lclizhao.sharebook.service.UserService;
import com.lclizhao.utils.AnnotionUtil;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.glassfish.jersey.server.Uri;

import org.springframework.beans.factory.annotation.Autowired;

//~--- JDK imports ------------------------------------------------------------

import java.io.File;
import java.io.InputStream;
import java.util.AbstractSet;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

/**
 * @Name:AnnotationResource.java
 * @Create Date: 15/12/07（创建日期）
 * @Description:
 *     笔记资源类
 * @version        1.0, 15/12/07
 * @author         Lizhao
 */
@Path("/annotation")
public class AnnotationResource {
    @Autowired
    AnnotationService annotationService;
    @Autowired
    CollectionService collectionService;
    @Autowired
    UserService userService;
    @Context
    SecurityContext securityContext;
    /**
     * author：Lizhao
     * Date:15/12/09
     * version:1.0
     *
     * @param fileInputStream
     * @param disposition
     * @param content
     * @param page_No
     * @param digest
     * @param ubId
     * @return Response HTTP状态码201
     *
     * @throws AppException
     */
    @POST
    @Consumes({ MediaType.MULTIPART_FORM_DATA })
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{ubId:[0-9A-Za-z]{32}}")
    public Response saveAnnotionResource(@FormDataParam("file") InputStream fileInputStream,
            @FormDataParam("file") FormDataContentDisposition disposition, @FormDataParam("content") String content,
            @FormDataParam("page") String page_No, @FormDataParam("digest") String digest,
            @PathParam("ubId") String ubId
    )
            throws AppException {
       
//      System.out.println(fileInputStream.toString());
//      System.out.println(disposition.getName()+" "+disposition.getFileName()+" "+disposition.getSize()+" "+disposition.getType()+" "+disposition.getParameters());
//      System.out.println(context);
        // 摘要和摘要图片二选一，没有摘要文字的时候就传这个
        AnnotionUtil.checkAnnotionResource(disposition, content, page_No, digest);
//        String tel=securityContext.getUserPrincipal().getName();
//        String userId=userService.findUserByTel(tel).getUserID();
        User_Book user_book=collectionService.getById(ubId);
        if(user_book==null&&!user_book.getUserId().equals("40289f0d51581b630151581b6d080000")){
            throw new AppException(404,4008,"link","NO Collection","No Collection");
        }
       Annotation annotation= annotationService.saveAnnotion(fileInputStream, disposition, content, page_No, digest, ubId);

        return Response.status(201).entity(annotation).build();
    }
}


//~ Formatted by Jindent --- http://www.jindent.com
