package com.lclizhao.sharebook.resource.Exception;/**
 * Created by lizhaoz on 2015/12/2.
 */

/**
 * @Name:
 * @Author: lizhao（作者）
 * @Version: V1.00 （版本号）
 * @Create Date: 2015-11-26（创建日期）
 * @Description:
 */
public class CollectionResource {
}
