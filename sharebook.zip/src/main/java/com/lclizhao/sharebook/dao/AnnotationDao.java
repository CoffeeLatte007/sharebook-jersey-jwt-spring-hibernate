package com.lclizhao.sharebook.dao;

//~--- non-JDK imports --------------------------------------------------------

import com.lclizhao.sharebook.daomain.Annotation;
import com.lclizhao.sharebook.daomain.User;

/**
 * @Name:
 * @Author: lizhao（作者）
 * @Version: V1.00 （版本号）
 * @Create Date: 15/12/07（创建日期）
 * @Description:
 * @PathParam
 *
 * @version        1.0, 15/12/07
 * @author         Lizhao    
 */
public interface AnnotationDao extends BaseDao<Annotation> {}


//~ Formatted by Jindent --- http://www.jindent.com
