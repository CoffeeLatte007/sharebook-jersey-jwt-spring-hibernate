package com.lclizhao.sharebook.dao;/**
 * Created by lizhaoz on 2015/11/26.
 */

import com.lclizhao.sharebook.daomain.User;

/**
 * @Name:UserDao
 * @Author: lizhao（作者）
 * @Version: V1.00 （版本号）
 * @Create Date: 2015-11-28（创建日期）
 * @Description:
 *
 */
public interface UserDao extends BaseDao<User>{
}
