package com.lclizhao.utils;/**
 * Created by lizhaoz on 2015/12/4.
 */

/**
 * @Name:
 * @Author: lizhao（作者）
 * @Version: V1.00 （版本号）
 * @Create Date: 2015-12-4（创建日期）
 * @Description:消息工具类
 */
public class MessageUtil {

}
