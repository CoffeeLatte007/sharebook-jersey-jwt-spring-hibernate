package com.lclizhao.utils;

/**
 * Created by lizhaoz on 2015/12/9.
 */

public class URL {
    public static  final String DIGEST="http://localhost:8080/share/webapi/annotation";
}
